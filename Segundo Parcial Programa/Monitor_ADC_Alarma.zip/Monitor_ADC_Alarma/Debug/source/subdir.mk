################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../source/Monitor_ADC_Alarma.c \
../source/adc_app.c \
../source/alarm_app.c \
../source/button_app.c \
../source/cmd_app.c \
../source/diag_app.c \
../source/led_app.c \
../source/semihost_hardfault.c \
../source/tick_app.c \
../source/uart_app.c 

C_DEPS += \
./source/Monitor_ADC_Alarma.d \
./source/adc_app.d \
./source/alarm_app.d \
./source/button_app.d \
./source/cmd_app.d \
./source/diag_app.d \
./source/led_app.d \
./source/semihost_hardfault.d \
./source/tick_app.d \
./source/uart_app.d 

OBJS += \
./source/Monitor_ADC_Alarma.o \
./source/adc_app.o \
./source/alarm_app.o \
./source/button_app.o \
./source/cmd_app.o \
./source/diag_app.o \
./source/led_app.o \
./source/semihost_hardfault.o \
./source/tick_app.o \
./source/uart_app.o 


# Each subdirectory must supply rules for building sources it contributes
source/%.o: ../source/%.c source/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -DCPU_MCXA156VLL -DCPU_MCXA156VLL_cm33 -DSDK_OS_BAREMETAL -DSERIAL_PORT_TYPE_UART=1 -DSDK_DEBUGCONSOLE=1 -DCR_INTEGER_PRINTF -DPRINTF_FLOAT_ENABLE=0 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -D__REDLIB__ -I"E:\Proyectos\2do Parcial\Parcial-2-C-2019-8253-Mario-Mata\Segundo Parcial Programa\Monitor_ADC_Alarma\drivers" -I"E:\Proyectos\2do Parcial\Parcial-2-C-2019-8253-Mario-Mata\Segundo Parcial Programa\Monitor_ADC_Alarma\CMSIS" -I"E:\Proyectos\2do Parcial\Parcial-2-C-2019-8253-Mario-Mata\Segundo Parcial Programa\Monitor_ADC_Alarma\CMSIS\m-profile" -I"E:\Proyectos\2do Parcial\Parcial-2-C-2019-8253-Mario-Mata\Segundo Parcial Programa\Monitor_ADC_Alarma\utilities" -I"E:\Proyectos\2do Parcial\Parcial-2-C-2019-8253-Mario-Mata\Segundo Parcial Programa\Monitor_ADC_Alarma\utilities\debug_console" -I"E:\Proyectos\2do Parcial\Parcial-2-C-2019-8253-Mario-Mata\Segundo Parcial Programa\Monitor_ADC_Alarma\device" -I"E:\Proyectos\2do Parcial\Parcial-2-C-2019-8253-Mario-Mata\Segundo Parcial Programa\Monitor_ADC_Alarma\device\periph1" -I"E:\Proyectos\2do Parcial\Parcial-2-C-2019-8253-Mario-Mata\Segundo Parcial Programa\Monitor_ADC_Alarma\component\serial_manager" -I"E:\Proyectos\2do Parcial\Parcial-2-C-2019-8253-Mario-Mata\Segundo Parcial Programa\Monitor_ADC_Alarma\component\lists" -I"E:\Proyectos\2do Parcial\Parcial-2-C-2019-8253-Mario-Mata\Segundo Parcial Programa\Monitor_ADC_Alarma\utilities\str" -I"E:\Proyectos\2do Parcial\Parcial-2-C-2019-8253-Mario-Mata\Segundo Parcial Programa\Monitor_ADC_Alarma\component\uart" -I"E:\Proyectos\2do Parcial\Parcial-2-C-2019-8253-Mario-Mata\Segundo Parcial Programa\Monitor_ADC_Alarma\utilities\debug_console\config" -I"E:\Proyectos\2do Parcial\Parcial-2-C-2019-8253-Mario-Mata\Segundo Parcial Programa\Monitor_ADC_Alarma\board" -I"E:\Proyectos\2do Parcial\Parcial-2-C-2019-8253-Mario-Mata\Segundo Parcial Programa\Monitor_ADC_Alarma\source" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m33 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__REDLIB__ -fstack-usage -specs=redlib.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-source

clean-source:
	-$(RM) ./source/Monitor_ADC_Alarma.d ./source/Monitor_ADC_Alarma.o ./source/adc_app.d ./source/adc_app.o ./source/alarm_app.d ./source/alarm_app.o ./source/button_app.d ./source/button_app.o ./source/cmd_app.d ./source/cmd_app.o ./source/diag_app.d ./source/diag_app.o ./source/led_app.d ./source/led_app.o ./source/semihost_hardfault.d ./source/semihost_hardfault.o ./source/tick_app.d ./source/tick_app.o ./source/uart_app.d ./source/uart_app.o

.PHONY: clean-source

